cp -f forkexit.c /usr/src/minix/servers/pm/
cd /usr/src
gmake build MKUPDATE=yes
